See http://www.omniglot.com/writing/norwegian.htm to know about "Landsmål was renamed Nynorsk (New Norwegian)" and "Riksmål is now officially known as Bokmål (book language)"

EPiServer default language codes for Norwegian are:

norsk (nynorsk)          nn 
norsk, nynorsk (Noreg)   nn-NO  
norsk                    no

so we assume that norsk (no) is Norwegian Bokmål (nb NO)
