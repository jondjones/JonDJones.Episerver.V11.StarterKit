//console.log('asdf');
var treeInitialized = false;
$.fn.tree = function (options) {
    if (!this.length || treeInitialized) return this;

    var root = this;
    root.find('li:first-child').addClass('firstChild');
    root.find('li:last-child').addClass('lastChild');
    treeInitialized = true;
    return this;
};

$(document).ready(function () {
    function getQueryString() {
        var result = {}, queryString = location.search.substring(1),
      re = /([^&=]+)=([^&]*)/g, m;

        while (m = re.exec(queryString)) {
            result[decodeURIComponent(m[1])] = decodeURIComponent(m[2]);
        }

        return result;
    }

    function serializeQueryString(qs) {
        var s = '?';
        for (var p in qs) {
            if (qs.hasOwnProperty(p)) {
                s += p + '=' + qs[p] + '&';
            }
        }
        s = s.substring(0, s.length - 1);
        return s;
    }

    if ($.browser.msie) {
        var maxHeight = 0;
        $('nav ul li').height("auto");
        $('nav ul li').each(function () { maxHeight = Math.max(maxHeight, $(this).height()); }).height(maxHeight);
    }

    if (Sammy) {
        var pathParts = document.location.pathname.split('/');
        var scriptName = pathParts.pop();
        var sammyStartUp = {
            'GoneUrls.aspx': function () {
                this.get('#/', function () {
                    $('.treeframe .tree').tree({
                        onSelect: function (id, label) {
                            $('.editPop .txtRedirectedUrl').val(label);
                            $('.editPop .txthidSelectedTargetId').val(id);
                        }
                    });
                });
            },
            'LicenseAndSettings.aspx': function () {
                this.get('#/', function () {
                    this.redirect('#/tableview');
                });
                this.get('#/tableview', function () {});
                this.get('#/expview', function () {});
                this.get('#/delview', function () { });
                this.get('#/rewview', function () { });
                this.get('#/rigview', function () { });
            }
        };

        var app = Sammy('.main', function () {
            /*
            Tab function that assumes the following structure
            <ul>
            <li class="selected?"><a href="#/tabname1"></a>
            <li><a href="#/tabname2"></a>
            </ul>
            <div>
            <div id="tabname1"></div>
            <div id="tabname2"></div>
            </div>
            Tab switches are handled by sammy's hashchange routes
            */
            var tabs = function (/*params tabs*/) {
                var tabElement = $('#tabs');
                var tabContentElement = $('#content');
                var args = Array.prototype.slice.call(arguments);

                var goToTab = function (tab, targetTabLink) {
                    return function () {
                        var targetTabContent = tabContentElement.find('#' + tab);
                        tabContentElement.children('section').not(targetTabContent).hide();
                        targetTabContent.show();

                        var aspnetForm = document.getElementById('aspnetForm');
                        var path = aspnetForm.action.split('#');
                        var action = path[0] + '#/' + tab;
                        aspnetForm.action = action;

                        tabElement.find('a').not(targetTabLink).closest('li').removeClass('selected');
                        targetTabLink.closest('li').addClass('selected');
                    };
                };

                args.forEach(function (tab) {

                    var targetTabLink = tabElement.find('[href~="#/' + tab + '"]');

                    targetTabLink.click(goToTab(tab, targetTabLink));

                    if (document.location.href.indexOf(tab) !== -1) {
                        goToTab(tab, targetTabLink)();
                    }

                }.bind(this));

            }.bind(this);

            (sammyStartUp[scriptName] || function () { }).bind(this)();

            tabs('tableview', 'expview', 'delview', 'rewview', 'rigview');
        });

        // start the application
        sammyStartUp[scriptName] && app.run('#/');
    }

    $('nav ul li:last').addClass("last");
    $('nav ul li:first').addClass("first");
    $('table.seoTabList tr th:last-child').addClass("last");

    /*tables*/
    $('table.expandable tr td:first-child').addClass("expandable");
    $('table.expandable tr td:first-child').click(function () {
        $(this).parent().toggleClass("expanded");
    });
    $('table.metadata tr td:first-child').removeClass("expandable");
    $('table.expandable tr td a').click(function (event) {
        var agent = jQuery.browser;
        if (agent.msie) {
            event.cancelBubble = true;
        } else {
            event.stopPropagation();
        }
    });

    $('#edit-settings').click(function () {
        $('#tblSettingsView').addClass("hidden");
        $('#tblSettingsEdit').removeClass("hidden");
        $('.successMessage').hide();
        return false;
    });

    /* 301, 404, 410 */

    $('a.editbutton').click(function (e) {

        var id = $(this).attr('data-id');
        var request = $(this).attr('data-request');
        var redirect = $(this).attr('data-redirect');

        $('.txtRequestUrl').val(request);
        $('.txtRedirectedUrl').val(redirect);
        $('.txthidSelectedUrlId').val(id);

        $('div.editPop').modal();
        $('#simplemodal-container').appendTo($('form:first'));

        return false;
    });
    $(".editNotFound").click(function () {
        var src = $(this).attr('href');
        openModalInIframe(src);
        return false;
    });
    $(".addbutton").click(function () {
        var src = $(this).attr('href');
        if (src != null && src != '' && src != 'undefined') {
            openModalInIframe(src);
            return false;
        } else {
            return true;
        }
    });
    $('#bulkLoadUrlsButton, #loadUrlsFromGoogleButton').click(function (e) {
        var src = $(this).attr('href');
        openModalInIframe(src);
        return false;
    });


    function openModalInIframe(src) {
        $.modal('<iframe src="' + src + '" scrolling="no" height="580px" frameborder="0" width="470px">', {
            onClose: function () {
                $.modal.close();
                var btnFilter = document.getElementById("ctl00_FullRegion_btnFilter") ? document.getElementById("ctl00_FullRegion_btnFilter") : document.getElementById("FullRegion_btnFilter");
                //window.location.reload(true);
                if (btnFilter) {
                    btnFilter.click();
                }
                else {
                    if (window.location.href.indexOf("#") > 0)
                        window.location.href = window.location.href.substr(0, window.location.href.indexOf("#"));
                    else
                        window.location.href = window.location.href;
                }
            }
        });
    }
});
//Call this from within iframe dialog to close the dialog
this.closeModalFromIframe = function () {
    parent.$.modal.close();
};
//tooltips
this.tooltip = function () {
    /* CONFIG */
    xOffset = -15;
    yOffset = -60;
    // these 2 variable determine popup's distance from the cursor
    // you might want to adjust to get the right result		
    /* END CONFIG */
    $("a.tooltip").hover(function (e) {
        this.t = this.title;
        this.title = "";
        $("body").append("<p id='tooltip'>" + this.t + "</p>");
        $("#tooltip")
			.css("top", (e.pageY - xOffset) + "px")
			.css("left", (e.pageX + yOffset) + "px")
			.fadeIn("fast");
    },
	function () {
	    this.title = this.t;
	    $("#tooltip").remove();
	});
    $("a.tooltip").mousemove(function (e) {
        $("#tooltip")
			.css("top", (e.pageY - xOffset) + "px")
			.css("left", (e.pageX + yOffset) + "px");
    });
};



// starting the script on page load
$(document).ready(function () {
    tooltip();
});
$(window).resize(function () {
    var maxHeight = 0;
    $('nav ul li').height("auto");
    $('nav ul li').each(function () { maxHeight = Math.max(maxHeight, $(this).height()); }).height(maxHeight);
});