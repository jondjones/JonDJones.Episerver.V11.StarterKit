define("epi-cms/content-approval/ApprovalStatus", {
    // summary:
    //      An enum containing the different statuses an approval can have.
    // tags:
    //      internal

    inReview: 0,
    approved: 1,
    rejected: 2
});
